/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.trabalhorecuperacao.frame;

import com.mycompany.trabalhorecuperacao.dao.ClienteDao;
import com.mycompany.trabalhorecuperacao.model.Cliente;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class FrameCadastroCliente extends javax.swing.JFrame {
    
    private ClienteDao clienteDao = new ClienteDao();
    private boolean clientePesquisado;
    private ArrayList<Cliente>lista;
    private Cliente novoCliente;
    
    private void atualizarGrid(){
        try{
            String sql = "SELECT nome, sobrenome, idade, endereco, \"numeroContato\" FROM public.\"Cliente\"; ";
            lista = new ArrayList<Cliente>();
            lista = clienteDao.retornaLista(sql);
            
            tbClientes.removeAll();
            
            DefaultTableModel tableModel = 
                    new DefaultTableModel(new Object[][]{},
                              new String[]{"Nome", "Sobrenome", "Idade", "Endereço", "Contato"}){
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            
             tbClientes.setModel(tableModel);
             
             
             DefaultTableModel dm = (DefaultTableModel)tbClientes.getModel();
            for (Cliente cliente : lista) {
                dm.addRow(new Object[]{cliente.getNome(), cliente.getSobrenome(), cliente.getIdade(), cliente.getEndereco(), cliente.getNumeroContato()});
            }
            
            tbClientes.getSelectionModel()
                    .addListSelectionListener(new ListSelectionListener() {
                @Override
                public void valueChanged(ListSelectionEvent e) {
                    int linhaSelecionada = tbClientes.getSelectedRow();
                    if(linhaSelecionada != -1)
                        mostrarCliente(lista.get(linhaSelecionada));
                }
            });
            
        }catch(Exception ex){
            
        }
    }
    
    public void limparCampos(){
        tfNomeCadastrarCliente.setText("");
        tfSobrenomeCadastrarCliente.setText("");
        tfDtNascimentoCadastrarCliente.setText("");
        tfEnderecoCadastrarCliente.setText("");
        tfContatoCadastrarCliente.setText("");
        
    }
    
    private void mostrarCliente(Cliente cliente){
        tfNomeCadastrarCliente.setText(String.valueOf(cliente.getNome()));
        tfSobrenomeCadastrarCliente.setText(cliente.getSobrenome());
        tfDtNascimentoCadastrarCliente.setText(String.valueOf(cliente.getIdade()));
        tfEnderecoCadastrarCliente.setText(cliente.getEndereco());
        tfContatoCadastrarCliente.setText(cliente.getNumeroContato());
        
        clientePesquisado = true;
    }
    
    private int calcularIdade(Date dataNascimento) {
        Calendar dob = Calendar.getInstance();
        dob.setTime(dataNascimento);
        Calendar today = Calendar.getInstance();
        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
            if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)) {
                age--;
            }
        return age;
}
    public FrameCadastroCliente() {
        initComponents();
        atualizarGrid();
        novoCliente = new Cliente();
    }


    @SuppressWarnings("unchecked")
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        tfNomeCadastrarCliente = new javax.swing.JTextField();
        tfSobrenomeCadastrarCliente = new javax.swing.JTextField();
        tfEnderecoCadastrarCliente = new javax.swing.JTextField();
        tfContatoCadastrarCliente = new javax.swing.JTextField();
        btFinalizarCadastroCliente = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbClientes = new javax.swing.JTable();
        tfDtNascimentoCadastrarCliente = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel2.setText("CADASTRAR CLIENTE");
        jLabel2.setToolTipText("");
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        jLabel1.setText("Nome");

        jLabel3.setText("Sobrenome");

        jLabel4.setText("Data Nascimento");

        jLabel5.setText("Endereço");

        jLabel6.setText("Contato");

        btFinalizarCadastroCliente.setText("Finalizar");
        btFinalizarCadastroCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btFinalizarCadastroClienteActionPerformed(evt);
            }
        });

        tbClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Nome", "Sobrenome", "Data Nascimento", "Endereço", "Contato"
            }
        ));
        jScrollPane1.setViewportView(tbClientes);

        tfDtNascimentoCadastrarCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tfDtNascimentoCadastrarClienteKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(133, 133, 133)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btFinalizarCadastroCliente))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 561, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel1))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(tfNomeCadastrarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(tfDtNascimentoCadastrarCliente))
                                    .addComponent(tfContatoCadastrarCliente)
                                    .addComponent(tfEnderecoCadastrarCliente)
                                    .addComponent(tfSobrenomeCadastrarCliente))))))
                .addGap(99, 99, 99))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel4)
                    .addComponent(tfNomeCadastrarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfDtNascimentoCadastrarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(tfSobrenomeCadastrarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(tfEnderecoCadastrarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(tfContatoCadastrarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addComponent(btFinalizarCadastroCliente)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(37, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btFinalizarCadastroClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btFinalizarCadastroClienteActionPerformed
    Cliente novoCliente = new Cliente();
        novoCliente.setNome(tfNomeCadastrarCliente.getText());
        novoCliente.setSobrenome(tfSobrenomeCadastrarCliente.getText());
        novoCliente.setIdade(Integer.parseInt(tfDtNascimentoCadastrarCliente.getText()));
        novoCliente.setEndereco(tfEnderecoCadastrarCliente.getText());
        novoCliente.setNumeroContato(tfContatoCadastrarCliente.getText());
        
        if (clienteDao.salvar(novoCliente)) {
        JOptionPane.showMessageDialog(this, 
                "Cliente salvo com Sucesso!",
                "Sucesso",
                JOptionPane.INFORMATION_MESSAGE);
                atualizarGrid();
        } else {
        JOptionPane.showMessageDialog(this, 
                "Erro ao salvar Cliente, solicite suporte técnico!",
                "Erro",
                JOptionPane.ERROR_MESSAGE);
        }
        atualizarGrid();
        limparCampos();
    }//GEN-LAST:event_btFinalizarCadastroClienteActionPerformed

    private void tfDtNascimentoCadastrarClienteKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfDtNascimentoCadastrarClienteKeyTyped
    
    }//GEN-LAST:event_tfDtNascimentoCadastrarClienteKeyTyped

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btFinalizarCadastroCliente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbClientes;
    private javax.swing.JTextField tfContatoCadastrarCliente;
    private javax.swing.JTextField tfDtNascimentoCadastrarCliente;
    private javax.swing.JTextField tfEnderecoCadastrarCliente;
    private javax.swing.JTextField tfNomeCadastrarCliente;
    private javax.swing.JTextField tfSobrenomeCadastrarCliente;
    // End of variables declaration//GEN-END:variables
}
