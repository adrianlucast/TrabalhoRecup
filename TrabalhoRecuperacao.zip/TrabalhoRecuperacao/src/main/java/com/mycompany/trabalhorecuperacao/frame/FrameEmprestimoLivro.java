package com.mycompany.trabalhorecuperacao.frame;

import com.mycompany.trabalhorecuperacao.dao.EmprestimoDao;
import com.mycompany.trabalhorecuperacao.model.Cliente;
import com.mycompany.trabalhorecuperacao.model.Emprestimo;
import com.mycompany.trabalhorecuperacao.model.Livro;
import com.mycompany.trabalhorecuperacao.conexaoBD.ConexaoPostgres;

import java.sql.Connection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.table.DefaultTableModel;
import javax.xml.crypto.Data;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;


/**
 *
 * @author adrian
 */
public class FrameEmprestimoLivro extends javax.swing.JFrame {
    
    private Connection connection;

    private EmprestimoDao emprestimoDao;
    private boolean livroPesquisado;
    private ArrayList<Emprestimo> lista;
    
    
    
    private void atualizarGrid() {
    try {
        String sql = "SELECT cliente, livro, \"dataEmprestimo\", \"dataDevolucao\" FROM public.\"Emprestimo\";";
        lista = new ArrayList<>();
        EmprestimoDao emprestimoDao = new EmprestimoDao(connection);
        lista = emprestimoDao.retornaLista(sql);

        DefaultTableModel tableModel = (DefaultTableModel) tbEmprestimoLivro.getModel();
        tableModel.setRowCount(0);

        for (Emprestimo emprestimo : lista) {
            tableModel.addRow(new Object[]{emprestimo.getCliente().getNome(), emprestimo.getLivro().getTitulo(), emprestimo.getDataEmprestimo(), emprestimo.getDataDevolucao()});
        }

    } catch (Exception ex) {
        ex.printStackTrace();
    }


}

    public void limparCampos() {
        tfLivroEmprestimoLivro.setText("");
        tfClienteEmprestimoLivro.setText("");
        tfDataEmprestimoLivro.setText("");
        tfDataDevolucaoEmprestimoLivro.setText("");
    }

    private void mostrarEmprestimo(Emprestimo emprestimo) {
    tfLivroEmprestimoLivro.setText(emprestimo.getLivro().getTitulo());
    tfClienteEmprestimoLivro.setText(emprestimo.getCliente().getNome());
    tfDataDevolucaoEmprestimoLivro.setText(String.valueOf(emprestimo.getDataEmprestimo()));
    tfDataDevolucaoEmprestimoLivro.setText(String.valueOf(emprestimo.getDataDevolucao()));

    livroPesquisado = true;
}

    public FrameEmprestimoLivro() {
        initComponents();
        connection = ConexaoPostgres.getConection();
        emprestimoDao = new EmprestimoDao(connection);
    }
    
   private void realizarEmprestimo(){
    String nomeCliente = tfClienteEmprestimoLivro.getText();
    String tituloLivro = tfLivroEmprestimoLivro.getText();
    String dataEmprestimoStr = tfDataEmprestimoLivro.getText();
    String dataDevolucaoStr = tfDataDevolucaoEmprestimoLivro.getText();
    
    
    if (nomeCliente.isEmpty() || tituloLivro.isEmpty() || dataEmprestimoStr.isEmpty() || dataDevolucaoStr.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, preencha todos os campos.", "Erro", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (!emprestimoDao.clienteExiste(nomeCliente)) {
        JOptionPane.showMessageDialog(this, "Cliente não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (!emprestimoDao.livroExiste(tituloLivro)) {
        JOptionPane.showMessageDialog(this, "Livro não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
        return;
    }

    Cliente cliente = new Cliente();
    cliente.setNome(nomeCliente);

    Livro livro = new Livro();
    livro.setTitulo(tituloLivro);

    Emprestimo emprestimo = new Emprestimo();
    emprestimo.setCliente(cliente);
    emprestimo.setLivro(livro);
    emprestimo.setDataEmprestimo(dataEmprestimoStr);
    emprestimo.setDataDevolucao(dataDevolucaoStr);

    int numExemplaresDisponiveis = livro.getNumExemplares();
    if (numExemplaresDisponiveis <= 0) {
        JOptionPane.showMessageDialog(this, "Não há exemplares disponíveis deste livro para empréstimo.", "Erro", JOptionPane.ERROR_MESSAGE);
        return;
    }

    livro.setNumExemplares(numExemplaresDisponiveis - 1);

    if (emprestimoDao.salvar(emprestimo)) {
        JOptionPane.showMessageDialog(this, "Empréstimo realizado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        atualizarGrid();
        limparCampos();
    } else {
        JOptionPane.showMessageDialog(this, "Erro ao salvar empréstimo, solicite suporte técnico!", "Erro", JOptionPane.ERROR_MESSAGE);
    }    
    
    adicionarEmprestimoNaInterface(emprestimo);

}
   
   private Date calcularDataDevolucao(Date dataEmprestimo) {
    Calendar cal = Calendar.getInstance();
    cal.setTime(dataEmprestimo);
    cal.add(Calendar.DAY_OF_MONTH, 14); 
    return cal.getTime();
}
   private void adicionarEmprestimoNaInterface(Emprestimo emprestimo) {
    DefaultTableModel tableModel = (DefaultTableModel) tbEmprestimoLivro.getModel();
    int rowCount = tableModel.getRowCount();
    int emptyRowIndex = -1;

    for (int i = 0; i < rowCount; i++) {
        boolean rowEmpty = true;
        for (int j = 0; j < tableModel.getColumnCount(); j++) {
            if (tableModel.getValueAt(i, j) != null) {
                rowEmpty = false;
                break;
            }
        }
        if (rowEmpty) {
            emptyRowIndex = i;
            break;
        }
    }

    if (emptyRowIndex != -1) {
        tableModel.setValueAt(emprestimo.getCliente().getNome(), emptyRowIndex, 0);
        tableModel.setValueAt(emprestimo.getLivro().getTitulo(), emptyRowIndex, 1);
        tableModel.setValueAt(emprestimo.getDataEmprestimo(), emptyRowIndex, 2);
        tableModel.setValueAt(emprestimo.getDataDevolucao(), emptyRowIndex, 3);
    } else { 
        tableModel.addRow(new Object[]{emprestimo.getCliente().getNome(), emprestimo.getLivro().getTitulo(), emprestimo.getDataEmprestimo(), emprestimo.getDataDevolucao()});
    }
}



   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        tfClienteEmprestimoLivro = new javax.swing.JTextField();
        tfLivroEmprestimoLivro = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        tfDataEmprestimoLivro = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        tfDataDevolucaoEmprestimoLivro = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        btEmprestimoLivro = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbEmprestimoLivro = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setText("EMPRESTIMO LIVRO");

        jLabel2.setText("Cliente");

        jLabel3.setText("Livro");

        tfDataEmprestimoLivro.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfDataEmprestimoLivroFocusLost(evt);
            }
        });
        tfDataEmprestimoLivro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfDataEmprestimoLivroActionPerformed(evt);
            }
        });

        jLabel4.setText("Data Empréstimo (dd/mm/yy)");

        tfDataDevolucaoEmprestimoLivro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfDataDevolucaoEmprestimoLivroActionPerformed(evt);
            }
        });

        jLabel5.setText("Data Devolução");

        btEmprestimoLivro.setText("Finalizar");
        btEmprestimoLivro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEmprestimoLivroActionPerformed(evt);
            }
        });

        tbEmprestimoLivro.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Cliente", "Livro", "Dt Emprestimo", "Dt Devolução"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tbEmprestimoLivro);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btEmprestimoLivro)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addComponent(jLabel4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(tfDataEmprestimoLivro, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel5)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(tfDataDevolucaoEmprestimoLivro))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addComponent(jLabel3)
                            .addGap(18, 18, 18)
                            .addComponent(tfLivroEmprestimoLivro))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addComponent(jLabel2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel1)
                                .addComponent(tfClienteEmprestimoLivro, javax.swing.GroupLayout.DEFAULT_SIZE, 470, Short.MAX_VALUE)))
                        .addComponent(jScrollPane1)))
                .addGap(0, 22, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1)
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(tfClienteEmprestimoLivro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(tfLivroEmprestimoLivro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(tfDataEmprestimoLivro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(tfDataDevolucaoEmprestimoLivro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btEmprestimoLivro)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btEmprestimoLivroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEmprestimoLivroActionPerformed
    String nomeCliente = tfClienteEmprestimoLivro.getText();
    String tituloLivro = tfLivroEmprestimoLivro.getText();
    String dataEmprestimo = tfDataEmprestimoLivro.getText();
    String dataDevolucao = tfDataDevolucaoEmprestimoLivro.getText();

    if (nomeCliente.isEmpty() || tituloLivro.isEmpty() || dataEmprestimo.isEmpty() || dataDevolucao.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, preencha todos os campos.", "Erro", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (!emprestimoDao.clienteExiste(nomeCliente)) {
        JOptionPane.showMessageDialog(this, "Cliente não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (!emprestimoDao.livroExiste(tituloLivro)) {
        JOptionPane.showMessageDialog(this, "Livro não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
        return;
    }

    Cliente cliente = new Cliente();
    cliente.setNome(nomeCliente);

    Livro livro = new Livro();
    livro.setTitulo(tituloLivro);

    Emprestimo emprestimo = new Emprestimo();
    emprestimo.setCliente(cliente); 
    emprestimo.setLivro(livro); 
    emprestimo.setDataEmprestimo(dataEmprestimo); 
    emprestimo.setDataDevolucao(dataDevolucao); 

    if (emprestimoDao.salvar(emprestimo)) {
        JOptionPane.showMessageDialog(this, "Empréstimo realizado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        adicionarEmprestimoNaInterface(emprestimo); 
        limparCampos();
    } else {
        JOptionPane.showMessageDialog(this, "Erro ao salvar empréstimo, solicite suporte técnico!", "Erro", JOptionPane.ERROR_MESSAGE);
    }

    }//GEN-LAST:event_btEmprestimoLivroActionPerformed

    private void tfDataDevolucaoEmprestimoLivroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfDataDevolucaoEmprestimoLivroActionPerformed
        tfDataEmprestimoLivro.addFocusListener(new java.awt.event.FocusAdapter() {
    public void focusLost(java.awt.event.FocusEvent evt) {
        String dataEmprestimoStr = tfDataEmprestimoLivro.getText();
        if (!dataEmprestimoStr.isEmpty()) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                Date dataEmprestimo = sdf.parse(dataEmprestimoStr);
                Date dataDevolucao = calcularDataDevolucao(dataEmprestimo);
                tfDataDevolucaoEmprestimoLivro.setText(sdf.format(dataDevolucao));
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
    }
});

    }//GEN-LAST:event_tfDataDevolucaoEmprestimoLivroActionPerformed

    private void tfDataEmprestimoLivroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfDataEmprestimoLivroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfDataEmprestimoLivroActionPerformed

    private void tfDataEmprestimoLivroFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfDataEmprestimoLivroFocusLost
    String dataEmprestimoStr = tfDataEmprestimoLivro.getText();
        if (!dataEmprestimoStr.isEmpty()) {
             try {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                Date dataEmprestimo = sdf.parse(dataEmprestimoStr);
                Date dataDevolucao = calcularDataDevolucao(dataEmprestimo);
                tfDataDevolucaoEmprestimoLivro.setText(sdf.format(dataDevolucao));
            } catch (ParseException e) {
                e.printStackTrace();
            }
}    }//GEN-LAST:event_tfDataEmprestimoLivroFocusLost

    /**
     * @param args the command line arguments
     */
  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btEmprestimoLivro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbEmprestimoLivro;
    private javax.swing.JTextField tfClienteEmprestimoLivro;
    private javax.swing.JTextField tfDataDevolucaoEmprestimoLivro;
    private javax.swing.JTextField tfDataEmprestimoLivro;
    private javax.swing.JTextField tfLivroEmprestimoLivro;
    // End of variables declaration//GEN-END:variables

   
}
