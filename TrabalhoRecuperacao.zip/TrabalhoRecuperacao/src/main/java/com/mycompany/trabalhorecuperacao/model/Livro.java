package com.mycompany.trabalhorecuperacao.model;

public class Livro {
    private String titulo;
    private String autor;
    private String editora;
    private String anoPublicacao;
    private int numExemplares;
    
    public Livro() {
        
    }
    
    public Livro(String titulo) {
        this.titulo = titulo;
    }

    // Getters
    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public String getEditora() {
        return editora;
    }

    public String getAnoPublicacao() {
        return anoPublicacao;
    }

    public int getNumExemplares() {
        return numExemplares;
    }

    // Setters
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public void setAnoPublicacao(String anoPublicacao) {
        this.anoPublicacao = anoPublicacao;
    }

    public void setNumExemplares(int numExemplares) {
        this.numExemplares = numExemplares;
    }

    @Override
    public String toString() {
        return titulo;
    }
    
}
