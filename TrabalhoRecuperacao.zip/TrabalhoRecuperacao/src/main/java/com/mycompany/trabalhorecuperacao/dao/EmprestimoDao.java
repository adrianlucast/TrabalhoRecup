package com.mycompany.trabalhorecuperacao.dao;

import com.mycompany.trabalhorecuperacao.conexaoBD.ConexaoPostgres;
import com.mycompany.trabalhorecuperacao.model.Cliente;
import com.mycompany.trabalhorecuperacao.model.Emprestimo;
import com.mycompany.trabalhorecuperacao.model.Livro;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EmprestimoDao extends GenericDao<Emprestimo> {

    Connection conn;

    public EmprestimoDao(Connection conn) {
        this.conn = conn;
    }

    @Override
    protected Emprestimo construirObjeto(ResultSet rs) {
        Emprestimo emprestimo = null;

        try {
            emprestimo = new Emprestimo();

            Cliente cliente = new Cliente();
            cliente.setNome(rs.getString("cliente"));
            emprestimo.setCliente(cliente);

            Livro livro = new Livro();
            livro.setTitulo(rs.getString("nomeLivro"));
            emprestimo.setLivro(livro);

            emprestimo.setDataEmprestimo(rs.getString("dataEmprestimo"));
            emprestimo.setDataDevolucao(rs.getString("dataDevolucao"));
        } catch (SQLException ex) {
            Logger.getLogger(EmprestimoDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return emprestimo;

    }

    @Override
    public boolean salvar(Emprestimo obj) {
        String sql = "INSERT INTO public.\"Emprestimo\"(cliente, livro ,\"dataEmprestimo\", \"dataDevolucao\") VALUES (?, ?, ?, ?);";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, obj.getCliente().getNome());
            ps.setString(2, obj.getLivro().getTitulo());
            ps.setString(3, obj.getDataEmprestimo());
            ps.setString(4, obj.getDataDevolucao());
            ps.executeUpdate();

            return true;
        } catch (SQLException ex) {
            Logger.getLogger(EmprestimoDao.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    @Override
    public boolean atualizar(Emprestimo obj) {
        String sql = "UPDATE public.\"Emprestimo\" SET cliente=?, livro=?, dataEmprestimo=?, dataDevolucao=? WHERE id=?;";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, obj.getCliente().getNome());
            ps.setString(2, obj.getLivro().getTitulo());
            ps.setString(3, obj.getDataEmprestimo());
            ps.setString(4, obj.getDataDevolucao());
            ps.executeUpdate();

            return true;
        } catch (SQLException ex) {
            Logger.getLogger(EmprestimoDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean clienteExiste(String nomeCliente) {
        String sql = "SELECT COUNT(*) FROM public.\"Cliente\" WHERE nome = ?;";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nomeCliente);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean livroExiste(String tituloLivro) {
        String sql = "SELECT COUNT(*) FROM public.\"Livro\" WHERE titulo = ?;";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, tituloLivro);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
