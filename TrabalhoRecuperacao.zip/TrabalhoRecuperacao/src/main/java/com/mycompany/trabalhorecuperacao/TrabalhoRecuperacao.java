/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalhorecuperacao;

import com.mycompany.trabalhorecuperacao.frame.FramePrincipal;
import javax.swing.JFrame;

/**
 *
 * @author adrian
 */
public class TrabalhoRecuperacao {

    public static void main(String[] args) {
        FramePrincipal frame = new FramePrincipal();
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setVisible(true);
    }
}
