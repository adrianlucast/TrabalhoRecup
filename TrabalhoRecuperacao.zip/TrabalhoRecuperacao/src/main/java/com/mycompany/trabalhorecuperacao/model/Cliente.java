package com.mycompany.trabalhorecuperacao.model;

import java.util.Calendar;
import java.util.Date;


public class Cliente {
    private String nome;
    private String sobrenome;
    private int idade;
    private String endereco;
    private String numeroContato;
    private Date dataNascimento;
    private int id;
    
    public int calcularIdade() {
    Calendar dataNascimento = Calendar.getInstance();
    dataNascimento.setTime(this.dataNascimento);
    Calendar hoje = Calendar.getInstance();

    int idade = hoje.get(Calendar.YEAR) - dataNascimento.get(Calendar.YEAR);
    if (hoje.get(Calendar.MONTH) < dataNascimento.get(Calendar.MONTH) ||
            (hoje.get(Calendar.MONTH) == dataNascimento.get(Calendar.MONTH) &&
            hoje.get(Calendar.DAY_OF_MONTH) < dataNascimento.get(Calendar.DAY_OF_MONTH))) {
        idade--;
    }
    return idade;
}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Cliente() {
               
    }

    public Cliente(String nomeCliente) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public String getNome() {
        return nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public int getIdade() {
        return idade;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getNumeroContato() {
        return numeroContato;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public void setNumeroContato(String numeroContato) {
        this.numeroContato = numeroContato;
    }
    
    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }
    
    public Date getDataNascimento() {
        return dataNascimento;
    }

    @Override
    public String toString() {
        return nome + " " + sobrenome;
    }
}