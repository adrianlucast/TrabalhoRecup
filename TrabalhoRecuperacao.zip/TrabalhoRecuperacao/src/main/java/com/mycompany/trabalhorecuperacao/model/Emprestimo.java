package com.mycompany.trabalhorecuperacao.model;

import java.util.Date;

public class Emprestimo {
    private Cliente cliente;
    private Livro livro;
    private String dataEmprestimo;
    private String dataDevolucao;


    public Cliente getCliente() {
        return cliente;
    }

    public Livro getLivro() {
        return livro;
    }

    public String getDataEmprestimo() {
        return dataEmprestimo;
    }

    public String getDataDevolucao() {
        return dataDevolucao;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public void setLivro(Livro livro) {
        this.livro = livro;
    }

    public void setDataEmprestimo(String dataEmprestimo) {
        this.dataEmprestimo = dataEmprestimo;
    }

    public void setDataDevolucao(String dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }

    @Override
    public String toString() {
        String clienteNome = (cliente != null) ? cliente.getNome() : "Cliente desconhecido";
        String livroTitulo = (livro != null) ? livro.getTitulo() : "Livro desconhecido";
        String dataEmprestimoStr = (dataEmprestimo != null) ? dataEmprestimo : "Data desconhecida";

    return clienteNome + " emprestou " + livroTitulo + " em " + dataEmprestimoStr;
}

}
