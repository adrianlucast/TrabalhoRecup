/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalhorecuperacao.dao;

import com.mycompany.trabalhorecuperacao.model.Cliente;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author adrian
 */
public class ClienteDao extends GenericDao<Cliente> {
    
    @Override
    protected Cliente construirObjeto(ResultSet rs) {
        Cliente cliente = null;
        
        try {
            cliente = new Cliente();
            cliente.setNome(rs.getString("nome"));
            cliente.setSobrenome(rs.getString("sobrenome"));
            cliente.setIdade(rs.getInt("idade"));
            cliente.setEndereco(rs.getString("endereco"));
            cliente.setNumeroContato(rs.getString("numeroContato"));
            
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cliente;
                
    }

    @Override
    
    public boolean salvar(Cliente obj) {
        String sql = "INSERT INTO public.\"Cliente\"( nome, sobrenome, idade, endereco, \"numeroContato\") VALUES (?, ?, ?, ?, ?);";
        
        PreparedStatement ps = null;
        
        try {
            ps = conn.prepareStatement(sql);
            ps.setString(1, obj.getNome());
            ps.setString(2, obj.getSobrenome());
            ps.setInt(3, obj.getIdade());
            ps.setString(4, obj.getEndereco());
            ps.setString(5, obj.getNumeroContato());
            ps.executeUpdate();
            ps.close();
            
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
        
    }

    @Override
    public boolean atualizar(Cliente obj) {
        String sql = "UPDATE public.\"Cliente\"	SET nome=?, sobrenome=?, idade=?, endereco=?, \"numeroContato\"=?, WHERE <condition>;";
        
        PreparedStatement ps = null;
        
        try {
            ps = conn.prepareStatement(sql);
            ps.setString(1, obj.getNome());
            ps.setString(2, obj.getSobrenome());
            ps.setInt(3, obj.getIdade());
            ps.setString(4, obj.getEndereco());
            ps.setString(5, obj.getNumeroContato());
            ps.executeUpdate();
            ps.close();
            
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
    
    
}
