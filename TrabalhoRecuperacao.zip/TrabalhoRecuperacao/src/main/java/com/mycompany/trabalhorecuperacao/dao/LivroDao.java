/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalhorecuperacao.dao;

import com.mycompany.trabalhorecuperacao.model.Cliente;
import com.mycompany.trabalhorecuperacao.model.Livro;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author adrian
 */
public class LivroDao extends GenericDao<Livro> {
    
    private Connection conn;
    
    public LivroDao(Connection conn) {
        this.conn = conn;
    }
    
     @Override
    protected Livro construirObjeto(ResultSet rs) {
        Livro livro = null;
        
        try {
            livro = new Livro();
            livro.setTitulo(rs.getString("titulo"));
            livro.setAutor(rs.getString("autor"));
            livro.setEditora(rs.getString("editora"));
            livro.setAnoPublicacao(rs.getString("anoPublicacao"));
            livro.setNumExemplares(rs.getInt("numExemplares"));
            
        } catch (SQLException ex) {
            Logger.getLogger(LivroDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return livro;
                
    }

    @Override
    
    public boolean salvar(Livro obj) {
        String sql = "INSERT INTO public.\"Livro\"(titulo, autor, editora, \"anoPublicacao\", \"numExemplares\") VALUES (?, ?, ?, ?, ?);";
        
        PreparedStatement ps = null;
        
        try {
            ps = conn.prepareStatement(sql);
            ps.setString(1, obj.getTitulo());
            ps.setString(2, obj.getAutor());
            ps.setString(3, obj.getEditora());
            ps.setString(4, obj.getAnoPublicacao());
            ps.setInt(5, obj.getNumExemplares());
            ps.executeUpdate();
            ps.close();
            
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(LivroDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
        
    }

    @Override
    public boolean atualizar(Livro obj) {
        String sql = "UPDATE public.\"Livro\" SET titulo=?, autor=?, editora=?, \"anoPublicacao\"=?, \"numExemplares\"=? WHERE id=?;";
        
        PreparedStatement ps = null;
        
        try {
            ps = conn.prepareStatement(sql);
            ps.setString(1, obj.getTitulo());
            ps.setString(2, obj.getAutor());
            ps.setString(3, obj.getEditora());
            ps.setString(4, obj.getAnoPublicacao());
            ps.setInt(5, obj.getNumExemplares());
            ps.executeUpdate();
            ps.close();
            
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(LivroDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
}
    
    
